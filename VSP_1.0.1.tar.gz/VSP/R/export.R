#' Export to Excel function
#'
#' This function takes analyzed activity assay data and exports it to two excel files, the first for the sigmoid voltage dependence data and the second for the dF/F over time data
#' @param sig A data frame containing voltage and dF/F data
#' @param volt A list of data frames, each containing time and voltage
#' @param dff A list of data frames, each containing time and dF/F
#' @import openxlsx
#' @export
export <- function(sig, volt, dff) {
  filename <- file.choose() # Prompt user for first excel file
  wb <- loadWorkbook(file = filename) # Loads the excel file into a workbook variable "wb"
  nameSheet <- readline(prompt="What is the name for these data? ") # Prompts for name of the sheet
  if("Sheet1" %in% names(wb)[1]) { # If the excel file is blank, copies data into first sheet
    renameWorksheet(wb, 1, nameSheet)
  } else {
    addWorksheet(wb, sheetName = nameSheet) # If the excel file is not blank, adds a new sheet with the data exported
  }
  writeData(wb, nameSheet, sig) # Adds data to the workbook
  saveWorkbook(wb, filename, overwrite=TRUE) # Saves the workbook to the excel file, overwrites it with the new data added
  #choose file for dff over time data
  filename <- file.choose()
  wb <- loadWorkbook(file = filename)
  if("Sheet1" %in% names(wb)[1]) {
    renameWorksheet(wb, 1, nameSheet)
  } else {
    addWorksheet(wb, sheetName = nameSheet)
  }
  total_trace <- data.frame("Time" = dff[[1]][,1]) # Makes a dataframe to hold all of the time, dFF, and voltage data for each trace
  for (i in 1:length(dff)) {
    total_trace[,(2*i)] <- volt[[i]][,2] # Adds voltage data for trace i
    total_trace[, (2*i + 1)] <- dff[[i]][,2] # Adds dF/F data for trace i
    colnames(total_trace)[(2*i):(2*i+1)] <- c(paste0("V", i), paste0("F", i)) # Changes column names, ex. "V1 , F1"
  }
  writeData(wb, nameSheet, total_trace)
  saveWorkbook(wb, filename, overwrite=TRUE)
  print("Export successful!") # If there are no errors in the program, prints out a happy little confirmation at the end
}
