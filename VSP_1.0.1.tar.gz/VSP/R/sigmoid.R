#' Sigmoid Function
#'
#' This function calculates y values for a sigmoid curve.
#' @param params Equation parameters for the sigmoid curve. A numeric vector in the order of "base, max, vhalf, rate"
#' @param x A numeric vector used to calculate the y values of the curve
#' @keywords sigmoid
#' @export

sigmoid = function(params, x) {
  (params[1] + params[2] / (1+exp((params[3]-x)/params[4]))) # dF/F = base + max / (1 + e^((vhalf-Voltage)/rate))
}
