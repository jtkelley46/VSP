#' PDF Export
#'
#' PDF export script for graphs generated from activity assay data
#' @param assay The name of the assay the data were collected with.
#' @param sig A data frame with voltage in the first column and dF/F in the second column, for fTAPP there is a third column
#' @param parm A data frame of parameters for the sigmoid curve fitting the data in 'sig'. No sigmoid curve will be plotted if omitted.
#' @param parm2 The parameters for the second sigmooid curve if analyzing fTAPP data.
#' @param trc A list of dataframes containing time and dF/F
#' @param volt A list of dataframes containing time and voltage (optional)
#' @param title A character string specifying the title for the graphs
#' @param scale Scale factor for auto-scaling graphs. 1 is the default and works for most gPLC data.
#' @param sigbound Numeric vector for FV graph y bounds, ex. c(-0.06, 0.04)
#' @param kinbound Numeric vector for kinetic data graph y bounds
#' @import viridisLite
#' @export
vsp_pdf <- function(assay = "activity", sig, parm, trc, volt, title, sigbound, kinbound, scale = 1, parm2 = NULL) {
  activ <- assay == "activity"
  cansig <- parm[1] != FALSE || !(missing(parm)) # Checks if a sigmoid curve fits the data
  isTapp <- length(sig) == 3 # Checks if data is fTAPP data by checking the length of the FV dataframe
  sigb <- !(missing(sigbound)) # If the user has provided y bounds for the graphs, these two logicals are TRUE
  kinb <- !(missing(kinbound))
  pdf(file = paste0(title, ".pdf"), width = 11, height = 8.5) # Creates the pdf file with given title and Letter size dimensions, changes output stream to pdf
  par(mfrow =c(2,2)) # Sets the plot format to be 2x2, this lines up the kinetic data with the voltage step plot
  if (activ) { # For gPLC, fPLC, fTAPP
    if (kinb) { # if y bounds provided for kinetic data, they are used
      ymin <- kinbound[1]
      ymax <- kinbound[2]
    } else {
      ymax = max(trc[[2]][10000:(nrow(trc[[1]])-10000), 2]) + .005 # Current y axis scale for kinetic data, can be altered by the script calling the function
      ymin = ymax * -2 * scale
    }
    plot(trc[[1]], type="l", ylim=c(ymin, ymax), main=title, xlab="Time (s)", ylab=expression(paste(Delta, "F/F")), lwd=0.4) # Plots the kinetic data
    pal <- c("#A20DFF", "#49FF26", "#FF1AC1", "#FFDB11", "#1600FF", "#FA0E0C", "#00F9F8", "#8F3907", "#FFF901", "#FE8C00", "#0CADFA", "#0DFF5D") # Creates palette used for line colors
    for (j in 2:13) {
      points(trc[[15-j]], type="l", col=pal[14-j], lwd=0.4)
    }
    legg <- c("180 mV", "160 mV", "140 mV", "120 mV", "100 mV", "80 mV", "60 mV", "40 mV", "20 mV", "0 mV", "-20 mV", "-60 mV", "-100 mV") # Legend
    legend("bottomleft", legend=legg, lty=1, lwd = 5, bg="white", col=c(pal, "black"), cex=0.6) # Legend format
    if (sigb) { # If y bounds provided for FV data, provides them here
      ymin <- sigbound[1]
      ymax <- sigbound[2]
    } else {
      ymin <- min(sig[,length(sig)]) - 0.001 # y axis scale for FV data, little to no tweaking required
      ymax <- max(sig[,2]) + 0.001
    }
    if (isTapp) { # for fTAPP
      cansig2 <- !(is.null(parm2)) # Checks if the second (down component) data can fit a curve
      plot(sig[,1], sig[,2], type="p", col= "purple", pch= 16, ylim = c(ymin, ymax),  main=title, xlab="Voltage (mV)", ylab=expression(paste(Delta, "F/F"))) # Plots the collected data points for the up component
      points(sig[,1], sig[,3], type="p", col="forestgreen", pch=16) # Adds the data points for the down component
      if (cansig) {points(-100:200, sigmoid(parm, -100:200), type="l", col="purple")} # Adds the regression curves, if possible
      if (cansig2) {points(-100:200, sigmoid(parm2, -100:200), type="l", col="forestgreen")}
    } else { # For gPLC and fPLC
      plot(sig[,1], sig[,2], type="p", ylim = c(ymin, ymax),  main=title, xlab="Voltage (mV)", ylab=expression(paste(Delta, "F/F"))) # Plots the actual collected data points
      if (cansig) {points(-100:200, sigmoid(parm, -100:200), type="l")} # Adds the regression curve
    }
    plot(volt[[1]], type="l", ylim=c(min(sig[1])-10, 220), main=title, xlab="Time (s)", ylab="Voltage (mV)", lwd=1.5) # Plots voltage over time data
    for (j in 2:13) {
      points(volt[[j]], type="l", col=pal[j-1], lwd=1.5)
    }
      legend("topleft", legend=legg, lty=1, lwd = 5, col=c(pal, "black"), cex=0.5)
  } else { # For VCF data
    ymax = max(trc[[1]][10000:(nrow(trc[[1]])-10000), 2]) + .005 # Numbers may be based on old sample rates for the VCF protocol
    ymin = min(trc[[36]][10000:(nrow(trc[[1]])-10000), 2])
    pal <- viridis(36) # Creates palette used for line colors
    plot(trc[[1]], type="l", ylim=c(ymin, ymax), main=title, col=pal[1], xlab="Time (s)", ylab=expression(paste(Delta, "F/F")), lwd=0.4)
    for (j in 2:36) {
      points(trc[[j]], type="l", col=pal[j], lwd=0.4)
    }
    legg = c("-150 mV", "-140 mV", "-130 mV", "-120 mV", "-110 mV", "-100 mV", "-90 mV", "-80 mV", "-70 mV", "-60 mV", "-50 mV", "-40 mV", "-30 mV", "-20 mV", "-10 mV", "0 mV", "10 mV", "20 mV", "30 mV", "40 mV", "50 mV", "60 mV", "70 mV", "80 mV", "90 mV", "100 mV", "110 mV", "120 mV", "130 mV", "140 mV", "150 mV", "160 mV", "170 mV", "180 mV", "190 mV", "200 mV") #Creates a list for the legends later, purely for clarity of code
    legend("bottomleft", legend=legg, lty=1, lwd = 5, bg="white", col=c(pal, "black"), cex=0.4, ncol=2)
    ymin <- min(sig[,length(sig)]) - 0.001
    ymax <- max(sig[,2]) + 0.001
    plot(sig[,1], sig[,2], type="p", ylim = c(ymin, ymax),  main=title, xlab="Voltage (mV)", ylab=expression(paste(Delta, "F/F"))) #Plots the actual collected data points
    if (cansig) {points(-200:200, sigmoid(parm, -200:200), type="l")}
    plot(volt[[1]], type="l", ylim=c(min(sig[1])-10, 220), col=pal[1], main=title, xlab="Time (s)", ylab="Voltage (mV)", lwd=1.5)
    for (j in 2:36) {
      points(volt[[j]], type="l", col=pal[j], lwd=1.5)
    }
    legend("topleft", legend=legg, lty=1, lwd = 5, col=c(pal), cex=0.5, ncol=2)
  }
  dev.off() # Changes the output stream back to RStudio
}
