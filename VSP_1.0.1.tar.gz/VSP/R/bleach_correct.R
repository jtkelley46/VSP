#' Bleach Correction
#'
#' Program that corrects for effects due to photobleaching of GFP through linear regression.
#' @param rawtrace The list of dF/F over time data, where each element is a dataframe
#' @param ctime The starting time (in seconds) for when the slope of bleaching should be drawn.
#' @param ilen The length (in seconds) of the interval to draw the bleach correction
#' @return The bleach corrected dF/F over time data. A list with 13 dataframes
#' @export

bleach_c <- function(rawtrace, ctime = 2, ilen = 1) {
  output <- list()
  cctime <- 10000*ctime # Converting from seconds to tenths of a millisecond, the time unit used in gPLC analysis
  iilen <- 10000*ilen
  for (i in 1:13) { # Linear model for each trace
    fitmodel <- lm(rawtrace[[i]][(cctime):(cctime+iilen),2] ~ rawtrace[[i]][(cctime):(cctime+iilen),1]) # dF/F = a + b * time
    slope <- coef(fitmodel)[2] # Get slope from model
    correct <- function(indata) {indata[,2] - indata[,1] * slope} # Correction function, I tried doing stuff with lapply but couldn't
    outt <- correct(rawtrace[[i]]) # Correct each trace, store corrected trace in outt
    output[[i]] <- data.frame("Time (s)" = rawtrace[[1]][,1], "dFF" = outt) # outt is stored in output[[i]]
  }
  return(output) # List of corrected traces returned
}
