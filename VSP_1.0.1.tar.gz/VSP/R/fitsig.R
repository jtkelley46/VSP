#' Sigmoid Fit
#'
#' Function that tries to fit dF/F vs Voltage data to a sigmoid curve, removing +180 mV points if necessary
#' @param sig Data frame of doubles with Voltage in the first column and dF/F in the second, if fTAPP then dF/F for the down-component in the third column.
#' @param assay Character string specifying whether the particular assay is gPLC, fPLC, fTAPP or VCF
#' @param exclude Logical specifying whether or not the regression may remove the +180 mV point(s) from its calculation. Defaults to TRUE
#' @return A numerical vector for the equation parameters, or a list with two elements (numerical vectors or FALSE) for fTAPP data, or FALSE if no sigmoid could be generated
#' @export

fit_sigmoid <- function(sig, assay, exclude = TRUE) {
  if (assay == "gplc") { # For gPLC analysis
    y <- sig[, 2]
    funct <- y ~ a + b/(1+exp((c-sig[, 1])/d)) # Creates a formula "funct" which describes the relation between V and dF/F with equation parameters a (base), b (max), c (xhalf), d (rate).
    fitmodel <- try(nls(funct, start=list(a=-0.1, b=0.048, c=29, d=5), control= nls.control(minFactor=1/4096, tol=0.1, maxiter = 100))) # "start" values are aproximate starting values for the regression, they work for all data with a sigmoid shape
    if (exclude && class(fitmodel) == "try-error") { # If the program is allowed to exclude the 180mV point from the regression AND the initial regression failed
      y <- c(sig[1,2], sig[3:13, 2]) # 180 mV point is removed from the datasets used for regression
      x <- c(sig[1,1], sig[3:13, 1])
      funct <- y ~ a + b/(1+exp((c-x)/d))
      fitmodel <- try(nls(funct, start=list(a=-0.1, b=0.048, c=29, d=5), control= nls.control(minFactor=1/4096, tol=0.1, maxiter = 100)))
    }
    if (class(fitmodel) != "try-error") {return(coef(fitmodel))} # If the regression is successful, return the coefficients
    return(FALSE) # If no curve fit, returns FALSE
  } else if (assay == "fplc") { # For fPLC analysis, same as above but with different start values
    y <- sig[, 2]
    funct <- y ~ a + b/(1+exp((c-sig[, 1])/d))
    fitmodel <- try(nls(funct, start=list(a=0.01, b=-0.04, c=80, d=5), control= nls.control(minFactor=1/4096, tol=0.1, maxiter = 100)))
    if (exclude && class(fitmodel) == "try-error") {
      y <- c(sig[1,2], sig[3:13, 2])
      x <- c(sig[1,1], sig[3:13, 1])
      funct <- y ~ a + b/(1+exp((c-x)/d))
      fitmodel <- try(nls(funct, start=list(a=0.01, b=-0.04, c=80, d=5), control= nls.control(minFactor=1/4096, tol=0.1, maxiter = 100)))
    }
    if (class(fitmodel) != "try-error") {return(coef(fitmodel))}
    return(FALSE)
  } else if (assay == "ftapp") { # For fTAPP analysis, two curves are generated
    y1 <- sig[, 2] # Everything is the same, except two curves are made, so twice the lines of code are required
    y2 <- sig[, 3]
    funct1 <- y1 ~ a + b/(1+exp((c-sig[, 1])/d))
    funct2 <- y2 ~ a + b/(1+exp((c-sig[, 1])/d))
    fitmodel1 <- try(nls(funct1, start=list(a=-0.1, b=0.048, c=29, d=5), control= nls.control(minFactor=1/4096, tol=0.1, maxiter = 100)))
    fitmodel2 <- try(nls(funct2, start=list(a=-0.1, b=0.048, c=29, d=-5), control= nls.control(minFactor=1/4096, tol=0.1, maxiter = 100)))
    if (exclude) {
      if (class(fitmodel1) == "try-error") {
        y <- c(sig[1,2], sig[3:13, 2])
        x <- c(sig[1,1], sig[3:13, 1])
        funct1 <- y ~ a + b/(1+exp((c-x)/d))
        fitmodel1 <- try(nls(funct1, start=list(a=-0.1, b=0.048, c=29, d=5), control= nls.control(minFactor=1/4096, tol=0.1, maxiter = 100)))
      }
      if (class(fitmodel2) == "try-error") {
        y <- c(sig[1,3], sig[3:13, 3])
        x <- c(sig[1,1], sig[3:13, 1])
        funct2 <- y ~ a + b/(1+exp((c-x)/d))
        fitmodel2 <- try(nls(funct2, start=list(a=-0.1, b=0.048, c=29, d=5), control= nls.control(minFactor=1/4096, tol=0.1, maxiter = 100)))
      }
    }
    output <- list(FALSE, FALSE) # Output is set as FALSE, FALSE as a starting value
    if (class(fitmodel1) != "try-error") {output[[1]] <- coef(fitmodel1)} # If a curve can be fit to the "up" data, the parameters are returned in output[[1]]
    if (class(fitmodel2) != "try-error") {output[[2]] <- coef(fitmodel2)} # If a curve can be fit to the "down" data, the parameters are returned in output[[2]]
    return(output) # If one or both of the data sets could not fit a curve, their index is occupied by FALSE
  }
  else if (assay == "vcf") { # For VCF analysis, same as gPLC/fPLC but without an "exclude" condition
    y <- sig[, 2]
    funct <- y ~ a + b/(1+exp((c-sig[, 1])/d))
    fitmodel <- try(nls(funct, start=list(a=0.01, b=-0.04, c=80, d=5), control= nls.control(minFactor=1/4096, tol=0.1, maxiter = 100)))
    if (class(fitmodel) != "try-error") {return(coef(fitmodel))}
    return(FALSE)
  }
}

